import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import "./OperatorDashboard.css";

const API = "https://localhost:7199";

export default function OperatorDashboard() {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // read operator from localStorage
  const userStr = localStorage.getItem("user");
  const user = userStr ? JSON.parse(userStr) : {};
  const operatorId = user.busOperatorId || user.BusOperatorId;

  const auth = () => {
    const token = localStorage.getItem("token");
    return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        if (!operatorId) throw new Error("No Operator ID found.");
        setLoading(true);
        const res = await axios.get(`${API}/api/Bus/operator/${operatorId}`, auth());
        if (!mounted) return;
        // extra safety: only keep this operator's buses
        const mine = (res.data || []).filter(
          b => String(b.busOperatorId) === String(operatorId)
        );
        setBuses(mine);
      } catch (e) {
        if (!mounted) return;
        setErr(e?.response?.data || e.message || "Failed to load buses.");
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [operatorId]);

  return (
    <div className="op-wrap">
      <header className="op-hero">
        <h1>Hello Bus Operator!</h1>
        <p>Welcome to the Operator Dashboard.</p>
      </header>

      <section className="op-grid">
        <Link to="/operator/buses" className="op-card">
          <div className="op-card-title">Manage Buses</div>
          <div className="op-card-sub">View, add or delete your buses</div>
        </Link>

        <Link to="/add-bus" className="op-card op-card-accent">
          <div className="op-card-title">+ Add Bus</div>
          <div className="op-card-sub">Create a new bus under your account</div>
        </Link>
      </section>

      <section className="op-list">
        <div className="op-list-head">
          <h3>Your Buses</h3>
          <Link to="/operator/buses" className="op-link">Open full list →</Link>
        </div>

        {loading ? (
          <p>Loading…</p>
        ) : err ? (
          <p className="op-error">{String(err)}</p>
        ) : buses.length === 0 ? (
          <p className="op-empty">No buses yet. Click “+ Add Bus” to create one.</p>
        ) : (
          <table className="op-table">
            <thead>
              <tr>
                <th>Number</th>
                <th>Type</th>
                <th>Route</th>
                <th>Departure</th>
                <th>Seats</th>
              </tr>
            </thead>
            <tbody>
              {buses.map(b => (
                <tr key={b.busId}>
                  <td>{b.busNumber}</td>
                  <td>{b.busType}</td>
                  <td>{b.route ? `${b.route.origin} ➔ ${b.route.destination}` : "-"}</td>
                  <td>{b.departureTime ? new Date(b.departureTime).toLocaleString() : "-"}</td>
                  <td>{b.totalSeats}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </div>
  );
}
