import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import "./UserProfile.css";

const API = "https://localhost:7199";

export default function UserProfile() {
  const token = localStorage.getItem("token");
  const storedUser = useMemo(() => {
    try { return JSON.parse(localStorage.getItem("user") || "null"); }
    catch { return null; }
  }, []);

  const [user, setUser] = useState(storedUser);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  // view/edit state
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ name: "", email: "", role: "" });

  // password state
  const [pwForm, setPwForm] = useState({ oldPassword: "", newPassword: "", confirm: "" });
  const [pwMsg, setPwMsg] = useState("");
  const [pwSaving, setPwSaving] = useState(false);

  useEffect(() => {
    if (!storedUser || !token) { setLoading(false); return; }
    setForm({ name: storedUser.name || "", email: storedUser.email || "", role: storedUser.role || "" });
    // Try to fetch the latest profile from API (optional, silent fail)
    axios.get(`${API}/api/Users/${storedUser.userId}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => {
      const u = res.data || storedUser;
      setUser(u);
      setForm({ name: u.name || "", email: u.email || "", role: u.role || "" });
    }).catch(() => {
      // fallback to local
      setUser(storedUser);
    }).finally(() => setLoading(false));
  }, [storedUser, token]);

  if (!token || !user) {
    return (
      <div className="up-card">
        <h2 className="up-title">Profile</h2>
        <div className="up-muted">Please log in to view your profile.</div>
      </div>
    );
  }

  // ----- password helpers -----
  const pwStrength = (s) => {
    const checks = {
      len: s.length >= 8,
      up: /[A-Z]/.test(s),
      lo: /[a-z]/.test(s),
      num: /\d/.test(s),
      sp: /[^A-Za-z0-9]/.test(s)
    };
    const score = Object.values(checks).filter(Boolean).length;
    if (score <= 2) return { label: "Weak", score, color: "#d42a2a" };
    if (score === 3 || score === 4) return { label: "Medium", score, color: "#e6a400" };
    return { label: "Strong", score, color: "#239c4d" };
  };
  const strength = pwStrength(pwForm.newPassword);
  const pwValid = strength.label === "Strong" && pwForm.newPassword === pwForm.confirm && pwForm.oldPassword.length > 0;

  // ----- profile save -----
  const saveProfile = async () => {
    setErr("");
    try {
      const payload = {
        userId: user.userId,
        name: form.name.trim(),
        email: form.email.trim(),
        role: form.role || user.role // keep same role
      };
      await axios.put(`${API}/api/Users/${user.userId}`, payload, {
        headers: { Authorization: `Bearer ${token}` }
      });
      // update localStorage + state
      const updated = { ...user, ...payload };
      localStorage.setItem("user", JSON.stringify(updated));
      setUser(updated);
      setEditing(false);
    } catch (e) {
      setErr(e?.response?.data || "Update failed");
    }
  };

  // ----- change password -----
  const changePassword = async () => {
    if (!pwValid) { setPwMsg("Please meet all password requirements."); return; }
    setPwMsg(""); setPwSaving(true);
    try {
      // Try primary endpoint
      await axios.post(`${API}/api/Users/change-password`, {
        userId: user.userId,
        oldPassword: pwForm.oldPassword,
        newPassword: pwForm.newPassword
      }, { headers: { Authorization: `Bearer ${token}` } });
      setPwMsg("Password updated successfully.");
      setPwForm({ oldPassword: "", newPassword: "", confirm: "" });
    } catch (e1) {
      // Fallback endpoint if your API uses a different route
      try {
        await axios.put(`${API}/api/Users/${user.userId}/password`, {
          oldPassword: pwForm.oldPassword,
          newPassword: pwForm.newPassword
        }, { headers: { Authorization: `Bearer ${token}` } });
        setPwMsg("Password updated successfully.");
        setPwForm({ oldPassword: "", newPassword: "", confirm: "" });
      } catch (e2) {
        setPwMsg(e2?.response?.data || e1?.response?.data || "Password change failed.");
      }
    } finally {
      setPwSaving(false);
    }
  };

  return (
    <div className="up-wrap">
      <div className="up-card">
        <h2 className="up-title">Profile</h2>
        {loading ? (
          <div className="up-muted">Loading…</div>
        ) : (
          <>
            {!editing ? (
              <>
                <div className="up-row"><span className="up-key">Name</span><span className="up-val">{user?.name || "—"}</span></div>
                <div className="up-row"><span className="up-key">Email</span><span className="up-val">{user?.email || "—"}</span></div>
                <div className="up-row"><span className="up-key">Role</span><span className="up-val">{user?.role || "—"}</span></div>
                <div className="up-actions">
                  <button className="up-btn" onClick={() => setEditing(true)}>Edit</button>
                </div>
              </>
            ) : (
              <>
                <label className="up-label">Name
                  <input className="up-input" value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})}/>
                </label>
                <label className="up-label">Email
                  <input className="up-input" type="email" value={form.email} onChange={(e)=>setForm({...form, email:e.target.value})}/>
                </label>
                <label className="up-label">Role
                  <input className="up-input" value={form.role} disabled />
                </label>
                {err && <div className="up-error">{String(err)}</div>}
                <div className="up-actions">
                  <button className="up-btn ghost" onClick={()=>{ setEditing(false); setForm({ name:user.name||"", email:user.email||"", role:user.role||"" }); }}>Cancel</button>
                  <button className="up-btn" onClick={saveProfile}>Save</button>
                </div>
              </>
            )}
          </>
        )}
      </div>

      <div className="up-card">
        <h3 className="up-subtitle">Change Password</h3>
        <label className="up-label">Current Password
          <input className="up-input" type="password" value={pwForm.oldPassword} onChange={(e)=>setPwForm({...pwForm, oldPassword:e.target.value})}/>
        </label>
        <label className="up-label">New Password
          <input className="up-input" type="password" value={pwForm.newPassword} onChange={(e)=>setPwForm({...pwForm, newPassword:e.target.value})}/>
        </label>

        {/* strength helper */}
        <div className="up-strength">
          <div className="up-meter">
            <span style={{ width: `${(strength.score/5)*100}%`, background: strength.color }} />
          </div>
          <span className="up-strength-text" style={{ color: strength.color }}>
            {strength.label} (need 8+ chars with upper, lower, number, special)
          </span>
        </div>

        <label className="up-label">Confirm New Password
          <input className="up-input" type="password" value={pwForm.confirm} onChange={(e)=>setPwForm({...pwForm, confirm:e.target.value})}/>
        </label>

        {pwMsg && <div className={`up-msg ${pwMsg.includes("success") ? "ok" : "err"}`}>{pwMsg}</div>}

        <div className="up-actions">
          <button
            className="up-btn"
            onClick={changePassword}
            disabled={!pwValid || pwSaving}
            title={!pwValid ? "Enter current password; new must be strong & match confirm" : ""}
          >
            {pwSaving ? "Updating…" : "Update Password"}
          </button>
        </div>
      </div>
    </div>
  );
}
