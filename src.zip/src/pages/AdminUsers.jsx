import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "https://localhost:7199";

// Try these in order until one succeeds (2xx)
const REGISTER_ENDPOINTS = [
  "/api/User/register",
  "/api/Users/register",
  "/api/Account/register",
  "/api/Authentication/register",
  "/api/Auth/Register",
];

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [deletingId, setDeletingId] = useState(null);

  // form state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("User");
  const [saving, setSaving] = useState(false);

  const auth = () => {
    const token = localStorage.getItem("token");
    return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
  };

  async function loadUsers() {
    try {
      setLoading(true);
      const res = await axios.get(`${API}/api/Users`, auth());
      setUsers(res.data || []);
    } catch (e) {
      setErr(e?.response?.data || e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    (async () => { await loadUsers(); })();
  }, []);

  async function deleteUser(id) {
    if (!window.confirm("Delete user?")) return;
    try {
      setDeletingId(id);
      await axios.delete(`${API}/api/Users/${id}`, auth());
      setUsers(prev => prev.filter(u => u.userId !== id));
    } catch (e) {
      alert(e?.response?.data || e.message);
    } finally {
      setDeletingId(null);
    }
  }

  // Try POST /api/Users first; then fall back through REGISTER_ENDPOINTS
  async function addUser(e) {
    e.preventDefault();
    setSaving(true);
    const body = { name, email, password, role };

    try {
      // attempt 1: POST /api/Users (some APIs support admin-create)
      try {
        await axios.post(`${API}/api/Users`, body, auth());
      } catch (e1) {
        // fallbacks: try common register endpoints
        let lastErr = e1;
        for (const ep of REGISTER_ENDPOINTS) {
          try {
            await axios.post(`${API}${ep}`, body, auth());
            lastErr = null;
            break;
          } catch (e2) {
            lastErr = e2;
          }
        }
        if (lastErr) {
          // build readable message listing results
          throw new Error(
            "Could not find a working register endpoint.\n" +
            "Tried: POST /api/Users and " + REGISTER_ENDPOINTS.join(", ")
          );
        }
      }

      setName(""); setEmail(""); setPassword(""); setRole("User");
      await loadUsers();
    } catch (e) {
      alert(e?.response?.data || e.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div style={{ padding: 40 }}>
      <h2 style={{ color: "#8e24aa", textAlign: "center" }}>Manage Users</h2>

      {/* Add User */}
      <form onSubmit={addUser} style={formRow}>
        <input style={input} placeholder="Name" value={name} onChange={e=>setName(e.target.value)} required />
        <input style={input} placeholder="Email" type="email" value={email} onChange={e=>setEmail(e.target.value)} required />
        <input style={input} placeholder="Password" type="password" value={password} onChange={e=>setPassword(e.target.value)} required />
        <select style={input} value={role} onChange={e=>setRole(e.target.value)}>
          <option value="User">User</option>
          <option value="BusOperator">BusOperator</option>
          <option value="Admin">Admin</option>
        </select>
        <button type="submit" disabled={saving} style={btn}>{saving ? "Saving..." : "Add User"}</button>
      </form>

      {loading ? <p>Loading...</p> : err ? <p style={{color:'crimson'}}>{String(err)}</p> : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={th}>UserId</th>
              <th style={th}>Name</th>
              <th style={th}>Email</th>
              <th style={th}>Role</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {users.map(u => (
              <tr key={u.userId}>
                <td style={td}>{u.userId}</td>
                <td style={td}>{u.name}</td>
                <td style={td}>{u.email}</td>
                <td style={td}>{u.role}</td>
                <td style={{...td, textAlign:"right"}}>
                  <button onClick={() => deleteUser(u.userId)} disabled={deletingId===u.userId}>
                    {deletingId===u.userId ? "Deleting..." : "Delete"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const th = { borderBottom: "1px solid #eee", padding: 12, textAlign: "left" };
const td = { borderBottom: "1px solid #f4f4f4", padding: 12 };
const formRow = { display:"grid", gridTemplateColumns:"1.1fr 1.2fr 1fr 0.8fr auto", gap:10, margin:"14px 0 22px" };
const input = { padding:"10px 12px", border:"1px solid #e9e9ef", borderRadius:10, outline:"none" };
const btn = { padding:"10px 14px", borderRadius:10, border:"1px solid #e9e9ef", background:"#f7c7e3", fontWeight:600 };
