import React from "react";
import { Link } from "react-router-dom";
import "./AdminDashboard.css";

export default function AdminDashboard() {
  return (
    <div className="ad-wrap">
      <header className="ad-hero">
        <h1>Hello Admin!</h1>
        <p>Welcome to the Admin Dashboard. (Build your controls here!)</p>
      </header>

      <section className="ad-grid">
        <Link to="/admin/users" className="ad-card">
          <div className="ad-card-title">Manage Users</div>
          <div className="ad-card-sub">Create, view, or remove users</div>
        </Link>

        <Link to="/admin/operators" className="ad-card">
          <div className="ad-card-title">Manage Operators</div>
          <div className="ad-card-sub">View all bus operators</div>
        </Link>

        <Link to="/admin/routes" className="ad-card">
          <div className="ad-card-title">Manage Routes</div>
          <div className="ad-card-sub">Add or remove routes</div>
        </Link>

        <Link to="/admin/buses" className="ad-card">
          <div className="ad-card-title">Manage Buses</div>
          <div className="ad-card-sub">Add / edit buses</div>
        </Link>

        <Link to="/admin/bookings" className="ad-card">
          <div className="ad-card-title">All Bookings</div>
          <div className="ad-card-sub">View every booking</div>
        </Link>
      </section>
    </div>
  );
}
