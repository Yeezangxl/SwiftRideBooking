import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./AdminDashboard.css";

export default function AdminDashboard() {
  const [userIdQuery, setUserIdQuery] = useState("");
  const navigate = useNavigate();

  const onSearch = (e) => {
    e.preventDefault();
    const q = (userIdQuery || "").trim();
    if (q) {
      navigate(`/admin/bookings?userId=${encodeURIComponent(q)}`);
    } else {
      navigate("/admin/bookings");
    }
  };

  return (
    <div className="ad-wrap">
      <header className="ad-hero">
        <h1>Hello Admin!</h1>
        <p>Welcome to the Admin Dashboard.</p>
      </header>

      {/* Quick Search: Bookings by User ID */}
      <section className="ad-search">
        <form onSubmit={onSearch} className="ad-search-box">
          <label htmlFor="admin-userid" className="ad-label">Quick search bookings by User ID</label>
          <div className="ad-input-row">
            <input
              id="admin-userid"
              className="ad-input"
              placeholder="Enter userId (GUID / numeric)"
              value={userIdQuery}
              onChange={(e) => setUserIdQuery(e.target.value)}
            />
            <button className="ad-btn" type="submit">Search</button>
            <button
              className="ad-btn ghost"
              type="button"
              onClick={() => { setUserIdQuery(""); navigate("/admin/bookings"); }}
            >
              Show All
            </button>
          </div>
          <div className="ad-hint">Tip: Paste the user’s ID and press Enter.</div>
        </form>
      </section>

      {/* App sections */}
      <section className="ad-grid">
        <Link to="/admin/users" className="ad-card">
          <div className="ad-card-title">Manage Users</div>
          <div className="ad-card-sub">Create, view, or remove users</div>
        </Link>

        <Link to="/admin/operators" className="ad-card">
          <div className="ad-card-title">Manage Operators</div>
          <div className="ad-card-sub">View all bus operators</div>
        </Link>

        <Link to="/admin/routes" className="ad-card">
          <div className="ad-card-title">Manage Routes</div>
          <div className="ad-card-sub">Add or remove routes</div>
        </Link>

        <Link to="/admin/buses" className="ad-card">
          <div className="ad-card-title">Manage Buses</div>
          <div className="ad-card-sub">Add / edit buses</div>
        </Link>

        <Link to="/admin/bookings" className="ad-card">
          <div className="ad-card-title">All Bookings</div>
          <div className="ad-card-sub">View every booking</div>
        </Link>
      </section>
    </div>
  );
}
