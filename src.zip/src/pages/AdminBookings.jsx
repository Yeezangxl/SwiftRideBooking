import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "https://localhost:7199";

export default function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  async function fetchBookings() {
    try {
      setLoading(true);
      const res = await axios.get(`${API}/api/Booking`);
      setBookings(res.data || []);
    } catch (e) {
      setErr(e?.response?.data || e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { fetchBookings(); }, []);

  return (
    <div style={{ padding: 40 }}>
      <h2 style={{ color: "#8e24aa", textAlign: "center" }}>All Bookings</h2>
      {loading ? <p>Loading...</p> : err ? <p style={{color:'crimson'}}>{String(err)}</p> : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={th}>BookingId</th>
              <th style={th}>UserId</th>
              <th style={th}>BusId</th>
              <th style={th}>JourneyDate</th>
              <th style={th}>SeatNumbers</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map(b => (
              <tr key={b.bookingId}>
                <td style={td}>{b.bookingId}</td>
                <td style={td}>{b.userId}</td>
                <td style={td}>{b.busId}</td>
                <td style={td}>{new Date(b.journeyDate).toLocaleDateString()}</td>
                <td style={td}>{b.seatNumbers}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const th = { borderBottom: "1px solid #eee", padding: 12, textAlign: "left" };
const td = { borderBottom: "1px solid #f4f4f4", padding: 12 };
