import React, { useEffect, useMemo, useState } from "react";
import { useLocation } from "react-router-dom";
import axios from "axios";
import "./AdminBookings.css";

const API = "https://localhost:7199";

export default function AdminBookings() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [query, setQuery] = useState("");
  const [searching, setSearching] = useState(false);

  // --- NEW: editor state (non-breaking) ---
  const [editOpen, setEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editData, setEditData] = useState({
    id: null,
    userId: "",
    busId: "",
    journeyDate: "",
    seatNumbers: "",
    boardingPointId: "",
    droppingPointId: ""
  });

  const location = useLocation();
  const token = localStorage.getItem("token");
  const admin = useMemo(() => {
    try { return JSON.parse(localStorage.getItem("user") || "null"); }
    catch { return null; }
  }, []);

  // ---- getters tolerant to shape differences ----
  const idOf = (b) => b?.bookingId ?? b?.BookingId ?? b?.id ?? b?.Id;
  const userIdOf = (b) =>
    b?.userId ?? b?.UserId ?? b?.user?.userId ?? b?.user?.id ?? b?.User?.Id ?? "—";
  const busIdOf = (b) => b?.busId ?? b?.BusId ?? b?.bus?.busId ?? b?.bus?.BusId ?? "";
  const busNoOf = (b) => b?.bus?.busNumber ?? b?.busNumber ?? b?.BusNo ?? "—";
  const routeOf = (b) => {
    const o = b?.bus?.route?.origin ?? b?.origin ?? b?.Origin ?? "—";
    const d = b?.bus?.route?.destination ?? b?.destination ?? b?.Destination ?? "—";
    return `${o} ➔ ${d}`;
  };
  const whenRaw = (b) =>
    b?.journeyDate ?? b?.bus?.departureTime ?? b?.departureTime ?? b?.Departure;
  const whenOf = (b) => {
    const d = whenRaw(b);
    try { return d ? new Date(d).toLocaleString() : "N/A"; } catch { return "N/A"; }
  };
  const seatsOf = (b) => b?.seatNumbers ?? b?.SeatNumbers ?? b?.seats ?? "—";
  const statusOf = (b) => (b?.status ?? b?.Status ?? "CONFIRMED").toUpperCase();
  const bpOf = (b) => b?.boardingPointId ?? b?.BoardingPointId ?? "";
  const dpOf = (b) => b?.droppingPointId ?? b?.DroppingPointId ?? "";

  // ---- loaders ----
  const loadAll = async () => {
    setLoading(true); setErr("");
    try {
      const res = await axios.get(`${API}/api/Booking`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBookings(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      setErr(e?.response?.data || "Failed to load bookings");
      setBookings([]);
    } finally {
      setLoading(false);
    }
  };

  const searchByUserId = async (userIdParam) => {
    const trimmed = (userIdParam ?? query ?? "").trim();
    if (!trimmed) { await loadAll(); return; }
    setErr("");
    setSearching(true);
    try {
      const res = await axios.get(`${API}/api/Booking/user/${encodeURIComponent(trimmed)}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBookings(Array.isArray(res.data) ? res.data : []);
    } catch (e) {
      setErr(e?.response?.data || "Search failed");
      setBookings([]);
    } finally {
      setSearching(false);
    }
  };

  // auto-run on querystring
  useEffect(() => {
    if (!token) { setLoading(false); return; }
    const params = new URLSearchParams(location.search);
    const q = params.get("userId");
    if (q) {
      setQuery(q);
      (async () => {
        setLoading(true);
        await searchByUserId(q);
        setLoading(false);
      })();
    } else {
      loadAll();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.search, token]);

  const triggerSearch = async () => {
    setLoading(true);
    await searchByUserId();
    setLoading(false);
  };
  const handleKeyDown = (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      triggerSearch();
    }
  };

  // --- NEW: helpers for edit modal ---
  const pad = (n) => String(n).padStart(2, "0");
  const toLocalInputValue = (raw) => {
    try {
      if (!raw) return "";
      const d = new Date(raw);
      if (Number.isNaN(d.getTime())) return "";
      return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    } catch { return ""; }
  };
  const openEditor = (row) => {
    setEditData({
      id: idOf(row),
      userId: String(userIdOf(row) ?? ""),
      busId: String(busIdOf(row) ?? ""),
      journeyDate: toLocalInputValue(whenRaw(row)),
      seatNumbers: String(row?.seatNumbers ?? row?.SeatNumbers ?? ""),
      boardingPointId: String(bpOf(row) ?? ""),
      droppingPointId: String(dpOf(row) ?? "")
    });
    setEditOpen(true);
  };
  const saveEdit = async () => {
    if (!editData.id) return;
    setSaving(true);
    try {
      const payload = {
        userId: Number(editData.userId) || 0,
        busId: Number(editData.busId) || 0,
        journeyDate: editData.journeyDate ? new Date(editData.journeyDate).toISOString() : null,
        seatNumbers: editData.seatNumbers || "",
        boardingPointId: editData.boardingPointId ? Number(editData.boardingPointId) : null,
        droppingPointId: editData.droppingPointId ? Number(editData.droppingPointId) : null
      };
      await axios.put(`${API}/api/Booking/${editData.id}`, payload, {
        headers: { Authorization: `Bearer ${token}` }
      });

      // optimistic local patch (do NOT replace whole object; keep nested Bus, Status, etc.)
      setBookings(prev => prev.map(b => {
        const id = idOf(b);
        if (id !== editData.id) return b;
        return {
          ...b,
          userId: payload.userId ?? b.userId,
          UserId: payload.userId ?? b.UserId,
          busId: payload.busId ?? b.busId,
          BusId: payload.busId ?? b.BusId,
          journeyDate: payload.journeyDate ?? b.journeyDate,
          // leave bus.departureTime intact if your backend ignores change
          seatNumbers: payload.seatNumbers ?? b.seatNumbers,
          SeatNumbers: payload.seatNumbers ?? b.SeatNumbers,
          boardingPointId: payload.boardingPointId ?? b.boardingPointId,
          BoardingPointId: payload.boardingPointId ?? b.BoardingPointId,
          droppingPointId: payload.droppingPointId ?? b.droppingPointId,
          DroppingPointId: payload.droppingPointId ?? b.DroppingPointId,
        };
      }));
      setEditOpen(false);
    } catch (e) {
      alert(e?.response?.data || "Update failed");
    } finally {
      setSaving(false);
    }
  };

  if (!token) {
    return (
      <div className="ab-card">
        <h2 className="ab-title">Admin · Bookings</h2>
        <div className="ab-muted">Please log in as Admin.</div>
      </div>
    );
  }

  return (
    <div className="ab-card">
      <h2 className="ab-title">Admin · Bookings</h2>

      <div className="ab-search">
        <div className="ab-search-left">
          <label htmlFor="userId" className="ab-label">Search by User ID</label>
          <input
            id="userId"
            className="ab-input"
            placeholder="Enter userId (GUID / numeric)"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={handleKeyDown}
          />
        </div>
        <div className="ab-search-right">
          <button className="ab-btn" onClick={triggerSearch} disabled={searching}>
            {searching ? "Searching…" : "Search"}
          </button>
          <button className="ab-btn ghost" onClick={loadAll} disabled={loading || searching}>
            Show All
          </button>
        </div>
      </div>

      {loading && <div className="ab-muted">Loading…</div>}
      {err && !loading && <div className="ab-error">{String(err)}</div>}

      {!loading && bookings.length === 0 && !err && (
        <div className="ab-muted">No results.</div>
      )}

      {!loading && bookings.length > 0 && (
        <div className="ab-table-wrap">
          <table className="ab-table">
            <thead>
              <tr>
                <th>Booking ID</th>
                <th>User ID</th>
                <th>Bus No</th>
                <th>Route</th>
                <th>Departure</th>
                <th>Seat(s)</th>
                <th>Status</th>
                {/* NEW */}<th>Action</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b, i) => (
                <tr key={idOf(b) ?? i}>
                  <td className="mono">{idOf(b) ?? "—"}</td>
                  <td className="mono">{userIdOf(b)}</td>
                  <td>{busNoOf(b)}</td>
                  <td>{routeOf(b)}</td>
                  <td>{whenOf(b)}</td>
                  <td>{seatsOf(b)}</td>
                  <td>
                    <span className={`ab-chip ${statusOf(b) === "CANCELLED" ? "ab-chip-red" : "ab-chip-green"}`}>
                      {statusOf(b)}
                    </span>
                  </td>
                  {/* NEW: Edit button */}
                  <td>
                    <button className="ab-btn" onClick={() => openEditor(b)}>
                      Edit
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* NEW: lightweight edit modal */}
      {editOpen && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,.45)",
          display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000
        }}>
          <div style={{
            width: "min(520px, 94vw)", background: "#fff", borderRadius: 14, padding: 16,
            boxShadow: "0 18px 50px rgba(0,0,0,.25)"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ margin: 0 }}>Edit Booking</h3>
              <button
                onClick={() => setEditOpen(false)}
                style={{ fontSize: 20, border: "none", background: "none", cursor: "pointer" }}
              >
                ×
              </button>
            </div>

            <div style={{ display: "grid", gap: 10, marginTop: 12 }}>
              <label>Booking ID
                <input value={editData.id ?? ""} readOnly className="ab-input" />
              </label>

              <label>User ID
                <input
                  className="ab-input"
                  value={editData.userId}
                  onChange={(e) => setEditData({ ...editData, userId: e.target.value })}
                />
              </label>

              <label>Bus ID
                <input
                  className="ab-input"
                  value={editData.busId}
                  onChange={(e) => setEditData({ ...editData, busId: e.target.value })}
                />
              </label>

              <label>Journey Date/Time
                <input
                  type="datetime-local"
                  className="ab-input"
                  value={editData.journeyDate}
                  onChange={(e) => setEditData({ ...editData, journeyDate: e.target.value })}
                />
              </label>

              <label>Seat Numbers (comma separated)
                <input
                  className="ab-input"
                  placeholder="A1,A2"
                  value={editData.seatNumbers}
                  onChange={(e) => setEditData({ ...editData, seatNumbers: e.target.value })}
                />
              </label>

              <label>Boarding Point ID
                <input
                  className="ab-input"
                  value={editData.boardingPointId}
                  onChange={(e) => setEditData({ ...editData, boardingPointId: e.target.value })}
                />
              </label>

              <label>Dropping Point ID
                <input
                  className="ab-input"
                  value={editData.droppingPointId}
                  onChange={(e) => setEditData({ ...editData, droppingPointId: e.target.value })}
                />
              </label>
            </div>

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 14 }}>
              <button className="ab-btn ghost" onClick={() => setEditOpen(false)}>Close</button>
              <button className="ab-btn" disabled={saving} onClick={saveEdit}>
                {saving ? "Saving…" : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
