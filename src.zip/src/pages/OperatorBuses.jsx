import React, { useEffect, useState } from "react";
import axios from "axios";

export default function OperatorBuses() {
  // Top-level log to prove this component is being rendered!
  console.log("OperatorBuses component is mounted!");
  console.log("!!! OperatorBuses.jsx is running !!!");


  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchOperatorBuses = async () => {
      setLoading(true);
      setError("");
      try {
        const token = localStorage.getItem("token");
        const userStr = localStorage.getItem("user");
        if (!token || !userStr) {
          setError("Not logged in.");
          setLoading(false);
          return;
        }
        const user = JSON.parse(userStr);
        // Support both camelCase and PascalCase for ID
        const id = user.busOperatorId || user.BusOperatorId;
        if (!id) {
          setError("No Operator ID found.");
          setLoading(false);
          return;
        }

        // API call
        const res = await axios.get(
          "https://localhost:7199/api/Bus/operator/" + id,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        // DEBUG LOGS: You will see these in the browser console!
        console.log("API buses", res.data);
        console.log("Operator ID", id, typeof id);

        // Defensive filtering: match even if type differs
        const filtered = (res.data || []).filter(
          (bus) => String(bus.busOperatorId) === String(id)
        );

        console.log("Filtered buses", filtered);

        setBuses(filtered);
      } catch (err) {
        setError(
          err?.response?.data?.message ||
            err?.message ||
            "Could not fetch buses."
        );
        setBuses([]);
      } finally {
        setLoading(false);
      }
    };

    fetchOperatorBuses();
  }, []);

  return (
    <div
      style={{
        maxWidth: 780,
        margin: "40px auto",
        background: "#fff",
        padding: "30px",
        borderRadius: 20,
        boxShadow: "0 6px 32px #e1bee740",
      }}
    >
      <h2 style={{ color: "#8e24aa", fontWeight: 700 }}>🚌 My Buses</h2>
      {loading ? (
        <div>Loading...</div>
      ) : error ? (
        <div style={{ color: "red" }}>{error}</div>
      ) : buses.length === 0 ? (
        <div style={{ color: "#b478d9" }}>
          No buses yet. Add your first bus!
        </div>
      ) : (
        <table
          style={{ width: "100%", marginTop: 22, borderCollapse: "collapse" }}
        >
          <thead>
            <tr style={{ background: "#faf7ff" }}>
              <th style={{ padding: 10 }}>Number</th>
              <th style={{ padding: 10 }}>Type</th>
              <th style={{ padding: 10 }}>Route</th>
              <th style={{ padding: 10 }}>Departure</th>
              <th style={{ padding: 10 }}>Seats</th>
            </tr>
          </thead>
          <tbody>
            {buses.map((bus) => (
              <tr key={bus.busId} style={{ borderBottom: "1.5px solid #eee" }}>
                <td style={{ padding: 8 }}>{bus.busNumber}</td>
                <td style={{ padding: 8 }}>{bus.busType}</td>
                <td style={{ padding: 8 }}>
                  {bus.route?.origin} ➔ {bus.route?.destination}
                </td>
                <td style={{ padding: 8 }}>
                  {bus.departureTime
                    ? new Date(bus.departureTime).toLocaleString()
                    : ""}
                </td>
                <td style={{ padding: 8 }}>{bus.totalSeats}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  ); 
}
