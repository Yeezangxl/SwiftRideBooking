import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import "./UserDashboard.css";

const API = "https://localhost:7199";

export default function UserDashboard() {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const token = localStorage.getItem("token");
  const user = useMemo(() => {
    try { return JSON.parse(localStorage.getItem("user") || "null"); }
    catch { return null; }
  }, []);

  const getId = (b) => b?.bookingId ?? b?.BookingId ?? b?.id ?? b?.Id;
  const getBusNo = (b) => b?.bus?.busNumber ?? b?.BusNo ?? b?.busNumber ?? "N/A";
  const getRoute = (b) => {
    const o = b?.bus?.route?.origin ?? b?.origin ?? b?.Origin ?? "—";
    const d = b?.bus?.route?.destination ?? b?.destination ?? b?.Destination ?? "—";
    return `${o} ➔ ${d}`;
  };
  const getDepartureRaw = (b) => b?.bus?.departureTime ?? b?.journeyDate ?? b?.departureTime ?? b?.Departure;
  const getDeparture = (b) => {
    const d = getDepartureRaw(b);
    try { return d ? new Date(d).toLocaleString() : "N/A"; } catch { return "N/A"; }
  };
  const getSeats = (b) => b?.seatNumbers ?? b?.SeatNumbers ?? b?.seats ?? "N/A";
  const getStatus = (b) => (b?.status ?? b?.Status ?? "CONFIRMED").toUpperCase();

  useEffect(() => {
    if (!user || !token) { setLoading(false); return; }
    setLoading(true);
    setErr("");
    axios
      .get(`${API}/api/Booking/user/${user.userId}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((res) => setBookings(Array.isArray(res.data) ? res.data : []))
      .catch((e) => { setErr(e?.response?.data || "Failed to load bookings"); setBookings([]); })
      .finally(() => setLoading(false));
  }, [user, token]);

  // Call soft-cancel endpoint, then hide the row
  const cancelBooking = async (b) => {
    const id = getId(b);
    if (!id) return;
    const ok = window.confirm("Cancel this booking? Seats will be released.");
    if (!ok) return;
    try {
      await axios.post(`${API}/api/Booking/${id}/cancel`, null, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setBookings((prev) => prev.filter((x) => getId(x) !== id));
    } catch (e) {
      alert(e?.response?.data || "Cancel failed");
    }
  };

  const canCancel = (b) => {
    const status = getStatus(b);
    if (status === "CANCELLED") return false;
    const raw = getDepartureRaw(b);
    if (!raw) return true;
    const ms = new Date(raw).getTime();
    return ms - Date.now() > 60 * 60 * 1000;
  };

  // hide cancelled from user view
  const visible = bookings.filter((b) => getStatus(b) !== "CANCELLED");

  if (!user || !token) {
    return (
      <div className="ud-card">
        <h2 className="ud-title">My Bookings</h2>
        <div className="ud-muted">Please log in to view bookings.</div>
      </div>
    );
  }

  return (
    <div className="ud-card">
      <h2 className="ud-title">👋 Welcome, {user?.name || "User"}!</h2>
      <h3 className="ud-sub">My Bookings</h3>

      {loading && <div className="ud-muted">Loading…</div>}
      {err && !loading && <div className="ud-error">{String(err)}</div>}

      {!loading && visible.length === 0 && !err && (
        <div className="ud-muted">No bookings yet. Go book a bus!</div>
      )}

      {!loading && visible.length > 0 && (
        <div className="ud-table-wrap">
          <table className="ud-table">
            <thead>
              <tr>
                <th>Bus No</th>
                <th>Route</th>
                <th>Departure</th>
                <th>Seat(s)</th>
                <th>Status</th>
                <th style={{width:120}}>Action</th>
              </tr>
            </thead>
            <tbody>
              {visible.map((b, i) => {
                const id = getId(b);
                const status = getStatus(b);
                const allow = canCancel(b);
                return (
                  <tr key={id ?? i}>
                    <td>{getBusNo(b)}</td>
                    <td>{getRoute(b)}</td>
                    <td>{getDeparture(b)}</td>
                    <td>{getSeats(b)}</td>
                    <td>
                      <span className={`ud-chip ${status === "CANCELLED" ? "ud-chip-red" : "ud-chip-green"}`}>
                        {status}
                      </span>
                    </td>
                    <td>
                      {allow ? (
                        <button className="ud-btn-cancel" onClick={() => cancelBooking(b)}>
                          Cancel
                        </button>
                      ) : (
                        <button className="ud-btn-disabled" disabled>
                          {status === "CANCELLED" ? "Cancelled" : "Locked"}
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
