import React, { useEffect, useState } from "react";
import axios from "axios";

const UserDashboard = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const token = localStorage.getItem("token");

  useEffect(() => {
    if (!user || !token) return;
    axios
      .get(`https://localhost:7199/api/Booking/user/${user.userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => setBookings(res.data))
      .catch(() => setBookings([]))
      .finally(() => setLoading(false));
  }, [user, token]);

  return (
    <div style={{
      maxWidth: 650,
      margin: "50px auto",
      background: "#fff",
      padding: "36px 32px",
      borderRadius: 18,
      boxShadow: "0 6px 22px #e1bee740"
    }}>
      <h2 style={{ color: "#8e24aa", fontWeight: 700, marginBottom: 12 }}>
        👋 Welcome, {user?.name || "User"}!
      </h2>
      <h3 style={{ fontSize: "1.3rem", color: "#b478d9", marginBottom: 18 }}>My Bookings</h3>
      {loading ? (
        <div>Loading...</div>
      ) : bookings.length === 0 ? (
        <div style={{ color: "#b478d9" }}>No bookings yet. Go book a bus!</div>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#faf7ff" }}>
              <th style={{ padding: 8, borderRadius: 8 }}>Bus No</th>
              <th style={{ padding: 8 }}>Route</th>
              <th style={{ padding: 8 }}>Departure</th>
              <th style={{ padding: 8 }}>Seat</th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b, i) => (
              <tr key={b.bookingId || i} style={{ borderBottom: "1.5px solid #eee" }}>
                <td style={{ padding: 7 }}>{b.bus?.busNumber || "N/A"}</td>
                <td style={{ padding: 7 }}>
                  {b.bus?.route?.origin} ➔ {b.bus?.route?.destination}
                </td>
                <td style={{ padding: 7 }}>
                  {b.bus?.departureTime
                    ? new Date(b.bus.departureTime).toLocaleString()
                    : "N/A"}
                </td>
                <td style={{ padding: 7 }}>{b.seatNumbers || "N/A"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default UserDashboard;
