import React, { useEffect, useState } from "react";
import axios from "axios";

export default function OperatorBuses() {
  const [buses, setBuses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const user = JSON.parse(localStorage.getItem("user") || "{}");
    if (!user.busOperatorId && !user.BusOperatorId) {
      setLoading(false);
      return;
    }
    const id = user.busOperatorId || user.BusOperatorId; // try both cases
    axios.get(`https://localhost:7199/api/Bus/operator/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => setBuses(res.data))
      .catch(() => setBuses([]))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={{ maxWidth: 780, margin: "40px auto", background: "#fff", padding: "30px", borderRadius: 20, boxShadow: "0 6px 32px #e1bee740" }}>
      <h2 style={{ color: "#8e24aa", fontWeight: 700 }}>🚌 My Buses</h2>
      {loading ? <div>Loading...</div> : (
        buses.length === 0 ?
          <div style={{ color: "#b478d9" }}>No buses yet. Add your first bus!</div>
          :
          <table style={{ width: "100%", marginTop: 22, borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ background: "#faf7ff" }}>
                <th style={{ padding: 10 }}>Number</th>
                <th style={{ padding: 10 }}>Type</th>
                <th style={{ padding: 10 }}>Route</th>
                <th style={{ padding: 10 }}>Departure</th>
                <th style={{ padding: 10 }}>Seats</th>
              </tr>
            </thead>
            <tbody>
              {buses.map(bus => (
                <tr key={bus.busId} style={{ borderBottom: "1.5px solid #eee" }}>
                  <td style={{ padding: 8 }}>{bus.busNumber}</td>
                  <td style={{ padding: 8 }}>{bus.busType}</td>
                  <td style={{ padding: 8 }}>{bus.route?.origin} ➔ {bus.route?.destination}</td>
                  <td style={{ padding: 8 }}>{bus.departureTime ? new Date(bus.departureTime).toLocaleString() : ""}</td>
                  <td style={{ padding: 8 }}>{bus.totalSeats}</td>
                </tr>
              ))}
            </tbody>
          </table>
      )}
      
    </div>
  );
}
