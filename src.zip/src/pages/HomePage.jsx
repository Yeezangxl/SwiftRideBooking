import React from "react";
import { useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";
import "./HomePage.css"; // Optional: for more styles if you want

export default function HomePage() {
  const navigate = useNavigate();

  return (
    <div className="homepage-bg">
      <div className="homepage-container">
        <img src={logo} alt="Swift Ride Logo" className="homepage-logo" />
        <h1 className="homepage-title">Swift Ride</h1>
        <p className="homepage-desc">
          Book intercity buses fast, easy, and safe.<br />
          Filter, sort, and ride with confidence.<br />
          <span style={{ color: "#a678dd" }}>No hassle. Just Swift.</span>
        </p>
        <button
          className="homepage-btn"
          onClick={() => navigate("/book")}
        >
          Book Your Bus Now
        </button>
      </div>
    </div>
  );
}
