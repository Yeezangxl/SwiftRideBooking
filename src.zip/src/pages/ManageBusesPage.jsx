import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "https://localhost:7199";
console.log("!!! ManageBusesPage.jsx is running !!!");

export default function ManageBusesPage() {
  const [buses, setBuses] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [deletingId, setDeletingId] = useState(null);
  const [saving, setSaving] = useState(false); // add form saving

  // --- NEW: edit modal state (separate from add form) ---
  const [editOpen, setEditOpen] = useState(false);
  const [editSaving, setEditSaving] = useState(false);
  const [editData, setEditData] = useState({
    busId: null,
    busNumber: "",
    busType: "",
    routeId: "",
    departureTime: "", // datetime-local value
    totalSeats: "",
    busOperatorId: ""  // only Admin can change
  });

  // Add form
  const [busNumber, setBusNumber] = useState("");
  const [busType, setBusType] = useState("");
  const [routeId, setRouteId] = useState("");
  const [departureTime, setDepartureTime] = useState("");
  const [totalSeats, setTotalSeats] = useState("");
  const [adminBusOperatorId, setAdminBusOperatorId] = useState("");

  // user + role
  const userStr = localStorage.getItem("user");
  const user = userStr ? JSON.parse(userStr) : {};
  const role = user.role || user.Role || "";

  const auth = () => {
    const token = localStorage.getItem("token");
    return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        setErr("");

        const token = localStorage.getItem("token");
        if (!token || !userStr) {
          if (mounted) setErr("Not logged in.");
          return;
        }

        // ✅ Everyone (Admin + BusOperator) sees ALL buses
        const busesRes = await axios.get(`${API}/api/Bus`, auth());
        const routesRes = await axios.get(`${API}/api/Route`, auth());

        if (!mounted) return;
        setBuses(busesRes.data || []);
        setRoutes(routesRes.data || []);
      } catch (e) {
        if (!mounted) return;
        setErr(e?.response?.data || e.message || "Failed to load data.");
        setBuses([]);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
    // eslint-disable-next-line
  }, []);

  async function refreshBuses() {
    try {
      setLoading(true);
      const r = await axios.get(`${API}/api/Bus`, auth());
      setBuses(r.data || []);
    } catch (e) {
      setErr(e?.response?.data || e.message || "Could not refresh buses.");
    } finally {
      setLoading(false);
    }
  }

  // ADD handler (unchanged)
  async function handleAdd(e) {
    e.preventDefault();
    try {
      setSaving(true);
      setErr("");

      let busOperatorId;
      if (role === "Admin") {
        if (!adminBusOperatorId) throw new Error("Please enter BusOperatorId.");
        busOperatorId = Number(adminBusOperatorId);
      } else if (role === "BusOperator") {
        busOperatorId = Number(user.busOperatorId || user.BusOperatorId);
        if (!busOperatorId) throw new Error("No Operator ID found in user.");
      } else {
        throw new Error("Unknown role.");
      }

      const payload = {
        busNumber: busNumber.trim(),
        busType: busType.trim(),
        routeId: Number(routeId),
        departureTime: departureTime ? new Date(departureTime).toISOString() : null,
        totalSeats: Number(totalSeats),
        busOperatorId,
      };

      if (!payload.busNumber || !payload.busType || !payload.routeId || !payload.totalSeats) {
        throw new Error("Please fill all required fields.");
      }

      await axios.post(`${API}/api/Bus`, payload, auth());

      // clear form
      setBusNumber("");
      setBusType("");
      setRouteId("");
      setDepartureTime("");
      setTotalSeats("");
      if (role === "Admin") setAdminBusOperatorId("");

      await refreshBuses();
    } catch (e) {
      alert(e?.response?.data || e.message || "Failed to add bus.");
    } finally {
      setSaving(false);
    }
  }

  // DELETE handler (unchanged)
  const handleDelete = async (busId) => {
    if (!window.confirm("Are you sure you want to delete this bus?")) return;
    setDeletingId(busId);
    try {
      await axios.delete(`${API}/api/Bus/${busId}`, auth());
      setBuses((prev) => prev.filter((bus) => bus.busId !== busId));
    } catch (err) {
      alert(err?.response?.data || err.message || "Failed to delete bus.");
    } finally {
      setDeletingId(null);
    }
  };

  const isOwner = (bus) =>
    String(bus.busOperatorId) === String(user.busOperatorId || user.BusOperatorId);

  // ====== EDIT (NEW) ======

  const pad = (n) => String(n).padStart(2, "0");
  const toLocalInput = (raw) => {
    try {
      if (!raw) return "";
      const d = new Date(raw);
      if (Number.isNaN(d.getTime())) return "";
      return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    } catch { return ""; }
  };

  const openEdit = (bus) => {
    setEditData({
      busId: bus.busId,
      busNumber: bus.busNumber || "",
      busType: bus.busType || "",
      routeId: String(bus.routeId ?? bus.route?.routeId ?? ""),
      departureTime: toLocalInput(bus.departureTime),
      totalSeats: String(bus.totalSeats ?? ""),
      busOperatorId: String(bus.busOperatorId ?? "")
    });
    setEditOpen(true);
  };

  const saveEdit = async () => {
    if (!editData.busId) return;

    // only Admin can change operator id; operator keeps theirs
    let finalBusOperatorId = editData.busOperatorId;
    if (role !== "Admin") {
      finalBusOperatorId = String(user.busOperatorId || user.BusOperatorId || "");
    }

    const payload = {
      busNumber: (editData.busNumber || "").trim(),
      busType: (editData.busType || "").trim(),
      routeId: editData.routeId ? Number(editData.routeId) : 0,
      departureTime: editData.departureTime ? new Date(editData.departureTime).toISOString() : null,
      totalSeats: editData.totalSeats ? Number(editData.totalSeats) : 0,
      busOperatorId: finalBusOperatorId ? Number(finalBusOperatorId) : null
    };

    if (!payload.busNumber || !payload.busType || !payload.routeId || !payload.totalSeats) {
      alert("Please fill all required fields.");
      return;
    }

    setEditSaving(true);
    try {
      await axios.put(`${API}/api/Bus/${editData.busId}`, payload, auth());

      // optimistic update in list (also refresh route label if route changed)
      setBuses(prev => prev.map(b => {
        if (b.busId !== editData.busId) return b;
        const updated = {
          ...b,
          busNumber: payload.busNumber,
          busType: payload.busType,
          routeId: payload.routeId,
          departureTime: payload.departureTime,
          totalSeats: payload.totalSeats,
          busOperatorId: payload.busOperatorId
        };
        // update nested route object for display if we know it
        const r = routes.find(x => x.routeId === payload.routeId);
        if (r) {
          updated.route = { ...b.route, routeId: r.routeId, origin: r.origin, destination: r.destination };
        }
        return updated;
      }));

      setEditOpen(false);
    } catch (e) {
      alert(e?.response?.data || e.message || "Failed to update bus.");
    } finally {
      setEditSaving(false);
    }
  };

  return (
    <div
      style={{
        maxWidth: 900,
        margin: "40px auto",
        background: "#fff",
        padding: "30px",
        borderRadius: 20,
        boxShadow: "0 6px 32px #e1bee740",
      }}
    >
      <h2 style={{ color: "#8e24aa", fontWeight: 700, marginTop: 0 }}>🚌 Manage Buses</h2>

      {/* ADD BUS FORM */}
      <form onSubmit={handleAdd} style={formRow(role)}>
        <input
          style={input}
          placeholder="Bus Number"
          value={busNumber}
          onChange={(e) => setBusNumber(e.target.value)}
          required
        />
        <input
          style={input}
          placeholder="Bus Type (AC, Sleeper...)"
          value={busType}
          onChange={(e) => setBusType(e.target.value)}
          required
        />
        <select
          style={input}
          value={routeId}
          onChange={(e) => setRouteId(e.target.value)}
          required
        >
          <option value="">Select Route</option>
          {routes.map((r) => (
            <option key={r.routeId} value={r.routeId}>
              {r.origin} ➔ {r.destination}
            </option>
          ))}
        </select>
        <input
          style={input}
          type="datetime-local"
          value={departureTime}
          onChange={(e) => setDepartureTime(e.target.value)}
          placeholder="Departure"
        />
        <input
          style={input}
          type="number"
          min={1}
          placeholder="Total Seats"
          value={totalSeats}
          onChange={(e) => setTotalSeats(e.target.value)}
          required
        />

        {/* Only Admin sees operator id input */}
        {role === "Admin" && (
          <input
            style={input}
            type="number"
            placeholder="BusOperatorId"
            value={adminBusOperatorId}
            onChange={(e) => setAdminBusOperatorId(e.target.value)}
            required
          />
        )}

        <button type="submit" disabled={saving} style={btnPrimary}>
          {saving ? "Saving..." : "Add Bus"}
        </button>
      </form>

      {loading ? (
        <div>Loading...</div>
      ) : err ? (
        <div style={{ color: "red", whiteSpace: "pre-wrap" }}>{err}</div>
      ) : buses.length === 0 ? (
        <div style={{ color: "#b478d9" }}>No buses yet. Add your first bus!</div>
      ) : (
        <table style={{ width: "100%", marginTop: 22, borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#faf7ff" }}>
              <th style={th}>Number</th>
              <th style={th}>Type</th>
              <th style={th}>Route</th>
              <th style={th}>Departure</th>
              <th style={th}>Seats</th>
              <th style={th}>Action</th>
            </tr>
          </thead>
          <tbody>
            {buses.map((bus) => (
              <tr key={bus.busId} style={{ borderBottom: "1.5px solid #eee" }}>
                <td style={td}>{bus.busNumber}</td>
                <td style={td}>{bus.busType}</td>
                <td style={td}>
                  {bus.route?.origin} ➔ {bus.route?.destination}
                </td>
                <td style={td}>
                  {bus.departureTime ? new Date(bus.departureTime).toLocaleString() : "-"}
                </td>
                <td style={td}>{bus.totalSeats}</td>
                <td style={{ ...td, display: "flex", gap: 8 }}>
                  {(role === "Admin" || (role === "BusOperator" && isOwner(bus))) && (
                    <>
                      {/* NEW: Edit button */}
                      <button
                        style={{
                          background: "#8e24aa",
                          color: "#fff",
                          border: "none",
                          borderRadius: 8,
                          padding: "6px 16px",
                          cursor: "pointer",
                        }}
                        onClick={() => openEdit(bus)}
                      >
                        Edit
                      </button>
                      <button
                        style={{
                          background: "#b90404",
                          color: "#fff",
                          border: "none",
                          borderRadius: 8,
                          padding: "6px 16px",
                          cursor: "pointer",
                          opacity: deletingId === bus.busId ? 0.5 : 1,
                        }}
                        onClick={() => handleDelete(bus.busId)}
                        disabled={deletingId === bus.busId}
                      >
                        {deletingId === bus.busId ? "Deleting..." : "Delete"}
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* === EDIT MODAL (NEW) === */}
      {editOpen && (
        <div style={{
          position: "fixed", inset: 0, background: "rgba(0,0,0,.45)",
          display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000
        }}>
          <div style={{
            background: "#fff",
            width: "min(520px, 94vw)",
            borderRadius: 16,
            padding: 18,
            boxShadow: "0 18px 50px rgba(0,0,0,.25)"
          }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ margin: 0 }}>Edit Bus</h3>
              <button
                onClick={() => setEditOpen(false)}
                style={{ fontSize: 20, border: "none", background: "none", cursor: "pointer" }}
              >
                ×
              </button>
            </div>

            <div style={{ display: "grid", gap: 10, marginTop: 12 }}>
              <label>Bus Number
                <input
                  style={input}
                  value={editData.busNumber}
                  onChange={e => setEditData({ ...editData, busNumber: e.target.value })}
                />
              </label>

              <label>Bus Type
                <input
                  style={input}
                  value={editData.busType}
                  onChange={e => setEditData({ ...editData, busType: e.target.value })}
                  placeholder="AC, Non-AC, Sleeper..."
                />
              </label>

              <label>Route
                <select
                  style={input}
                  value={editData.routeId}
                  onChange={e => setEditData({ ...editData, routeId: e.target.value })}
                >
                  <option value="">Select Route</option>
                  {routes.map(r => (
                    <option key={r.routeId} value={r.routeId}>
                      {r.origin} ➔ {r.destination}
                    </option>
                  ))}
                </select>
              </label>

              <label>Departure
                <input
                  style={input}
                  type="datetime-local"
                  value={editData.departureTime}
                  onChange={e => setEditData({ ...editData, departureTime: e.target.value })}
                />
              </label>

              <label>Total Seats
                <input
                  style={input}
                  type="number"
                  min={1}
                  value={editData.totalSeats}
                  onChange={e => setEditData({ ...editData, totalSeats: e.target.value })}
                />
              </label>

              {role === "Admin" && (
                <label>Bus Operator Id
                  <input
                    style={input}
                    type="number"
                    value={editData.busOperatorId}
                    onChange={e => setEditData({ ...editData, busOperatorId: e.target.value })}
                  />
                </label>
              )}
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, marginTop: 14 }}>
              <button
                style={{
                  padding: "10px 14px",
                  borderRadius: 10,
                  border: "1px solid #e9e9ef",
                  background: "#faf7ff",
                  color: "#8e24aa",
                  cursor: "pointer",
                }}
                onClick={() => setEditOpen(false)}
              >
                Close
              </button>
              <button
                style={{
                  padding: "10px 14px",
                  borderRadius: 10,
                  border: "1px solid #e9e9ef",
                  background: "#f7c7e3",
                  fontWeight: 700,
                  cursor: "pointer",
                }}
                onClick={saveEdit}
                disabled={editSaving}
              >
                {editSaving ? "Saving..." : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}

/* styles */
const th = { padding: 10, textAlign: "left" };
const td = { padding: 8 };

// grid adapts: Admin has an extra input
const formRow = (role) => ({
  display: "grid",
  gridTemplateColumns:
    role === "Admin"
      ? "1fr 1fr 1fr 1fr 0.7fr 0.8fr auto" // + operator id for Admin
      : "1fr 1fr 1fr 1fr 0.7fr auto",
  gap: 10,
  margin: "0 0 18px",
  alignItems: "center",
});

const input = {
  padding: "10px 12px",
  border: "1px solid #e9e9ef",
  borderRadius: 10,
  outline: "none",
};

const btnPrimary = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #e9e9ef",
  background: "#f7c7e3",
  fontWeight: 700,
  cursor: "pointer",
};
