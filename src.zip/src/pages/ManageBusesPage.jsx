import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "https://localhost:7199";
console.log("!!! ManageBusesPage.jsx is running !!!");

export default function ManageBusesPage() {
  const [buses, setBuses] = useState([]);
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [deletingId, setDeletingId] = useState(null);
  const [saving, setSaving] = useState(false);

  // Add form
  const [busNumber, setBusNumber] = useState("");
  const [busType, setBusType] = useState("");
  const [routeId, setRouteId] = useState("");
  const [departureTime, setDepartureTime] = useState("");
  const [totalSeats, setTotalSeats] = useState("");
  const [adminBusOperatorId, setAdminBusOperatorId] = useState("");

  // user + role
  const userStr = localStorage.getItem("user");
  const user = userStr ? JSON.parse(userStr) : {};
  const role = user.role || user.Role || "";

  const auth = () => {
    const token = localStorage.getItem("token");
    return token ? { headers: { Authorization: `Bearer ${token}` } } : {};
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        setErr("");

        const token = localStorage.getItem("token");
        if (!token || !userStr) {
          if (mounted) setErr("Not logged in.");
          return;
        }

        // ✅ Everyone (Admin + BusOperator) sees ALL buses
        const busesRes = await axios.get(`${API}/api/Bus`, auth());
        const routesRes = await axios.get(`${API}/api/Route`, auth());

        if (!mounted) return;
        setBuses(busesRes.data || []);
        setRoutes(routesRes.data || []);
      } catch (e) {
        if (!mounted) return;
        setErr(e?.response?.data || e.message || "Failed to load data.");
        setBuses([]);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
    // eslint-disable-next-line
  }, []);

  async function refreshBuses() {
    try {
      setLoading(true);
      const r = await axios.get(`${API}/api/Bus`, auth());
      setBuses(r.data || []);
    } catch (e) {
      setErr(e?.response?.data || e.message || "Could not refresh buses.");
    } finally {
      setLoading(false);
    }
  }

  // ADD handler (unchanged: Admin sets operator id; operator uses their own)
  async function handleAdd(e) {
    e.preventDefault();
    try {
      setSaving(true);
      setErr("");

      let busOperatorId;
      if (role === "Admin") {
        if (!adminBusOperatorId) throw new Error("Please enter BusOperatorId.");
        busOperatorId = Number(adminBusOperatorId);
      } else if (role === "BusOperator") {
        busOperatorId = Number(user.busOperatorId || user.BusOperatorId);
        if (!busOperatorId) throw new Error("No Operator ID found in user.");
      } else {
        throw new Error("Unknown role.");
      }

      const payload = {
        busNumber: busNumber.trim(),
        busType: busType.trim(),
        routeId: Number(routeId),
        departureTime: departureTime ? new Date(departureTime).toISOString() : null,
        totalSeats: Number(totalSeats),
        busOperatorId,
      };

      if (!payload.busNumber || !payload.busType || !payload.routeId || !payload.totalSeats) {
        throw new Error("Please fill all required fields.");
      }

      await axios.post(`${API}/api/Bus`, payload, auth());

      // clear form
      setBusNumber("");
      setBusType("");
      setRouteId("");
      setDepartureTime("");
      setTotalSeats("");
      if (role === "Admin") setAdminBusOperatorId("");

      await refreshBuses();
    } catch (e) {
      alert(e?.response?.data || e.message || "Failed to add bus.");
    } finally {
      setSaving(false);
    }
  }

  // DELETE handler (Admin or owner, same behavior as before)
  const handleDelete = async (busId) => {
    if (!window.confirm("Are you sure you want to delete this bus?")) return;
    setDeletingId(busId);
    try {
      await axios.delete(`${API}/api/Bus/${busId}`, auth());
      setBuses((prev) => prev.filter((bus) => bus.busId !== busId));
    } catch (err) {
      alert(err?.response?.data || err.message || "Failed to delete bus.");
    } finally {
      setDeletingId(null);
    }
  };

  const isOwner = (bus) =>
    String(bus.busOperatorId) === String(user.busOperatorId || user.BusOperatorId);

  return (
    <div
      style={{
        maxWidth: 900,
        margin: "40px auto",
        background: "#fff",
        padding: "30px",
        borderRadius: 20,
        boxShadow: "0 6px 32px #e1bee740",
      }}
    >
      <h2 style={{ color: "#8e24aa", fontWeight: 700, marginTop: 0 }}>🚌 Manage Buses</h2>

      {/* ADD BUS FORM */}
      <form onSubmit={handleAdd} style={formRow(role)}>
        <input
          style={input}
          placeholder="Bus Number"
          value={busNumber}
          onChange={(e) => setBusNumber(e.target.value)}
          required
        />
        <input
          style={input}
          placeholder="Bus Type (AC, Sleeper...)"
          value={busType}
          onChange={(e) => setBusType(e.target.value)}
          required
        />
        <select
          style={input}
          value={routeId}
          onChange={(e) => setRouteId(e.target.value)}
          required
        >
          <option value="">Select Route</option>
          {routes.map((r) => (
            <option key={r.routeId} value={r.routeId}>
              {r.origin} ➔ {r.destination}
            </option>
          ))}
        </select>
        <input
          style={input}
          type="datetime-local"
          value={departureTime}
          onChange={(e) => setDepartureTime(e.target.value)}
          placeholder="Departure"
        />
        <input
          style={input}
          type="number"
          min={1}
          placeholder="Total Seats"
          value={totalSeats}
          onChange={(e) => setTotalSeats(e.target.value)}
          required
        />

        {/* Only Admin sees operator id input */}
        {role === "Admin" && (
          <input
            style={input}
            type="number"
            placeholder="BusOperatorId"
            value={adminBusOperatorId}
            onChange={(e) => setAdminBusOperatorId(e.target.value)}
            required
          />
        )}

        <button type="submit" disabled={saving} style={btnPrimary}>
          {saving ? "Saving..." : "Add Bus"}
        </button>
      </form>

      {loading ? (
        <div>Loading...</div>
      ) : err ? (
        <div style={{ color: "red", whiteSpace: "pre-wrap" }}>{err}</div>
      ) : buses.length === 0 ? (
        <div style={{ color: "#b478d9" }}>No buses yet. Add your first bus!</div>
      ) : (
        <table style={{ width: "100%", marginTop: 22, borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#faf7ff" }}>
              <th style={th}>Number</th>
              <th style={th}>Type</th>
              <th style={th}>Route</th>
              <th style={th}>Departure</th>
              <th style={th}>Seats</th>
              {/* OperatorId column removed */}
              <th style={th}>Action</th>
            </tr>
          </thead>
          <tbody>
            {buses.map((bus) => (
              <tr key={bus.busId} style={{ borderBottom: "1.5px solid #eee" }}>
                <td style={td}>{bus.busNumber}</td>
                <td style={td}>{bus.busType}</td>
                <td style={td}>
                  {bus.route?.origin} ➔ {bus.route?.destination}
                </td>
                <td style={td}>
                  {bus.departureTime ? new Date(bus.departureTime).toLocaleString() : "-"}
                </td>
                <td style={td}>{bus.totalSeats}</td>
                <td style={td}>
                  {(role === "Admin" || (role === "BusOperator" && isOwner(bus))) && (
                    <button
                      style={{
                        background: "#b90404",
                        color: "#fff",
                        border: "none",
                        borderRadius: 8,
                        padding: "6px 16px",
                        cursor: "pointer",
                        opacity: deletingId === bus.busId ? 0.5 : 1,
                      }}
                      onClick={() => handleDelete(bus.busId)}
                      disabled={deletingId === bus.busId}
                    >
                      {deletingId === bus.busId ? "Deleting..." : "Delete"}
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

/* styles */
const th = { padding: 10, textAlign: "left" };
const td = { padding: 8 };

// grid adapts: Admin has an extra input
const formRow = (role) => ({
  display: "grid",
  gridTemplateColumns:
    role === "Admin"
      ? "1fr 1fr 1fr 1fr 0.7fr 0.8fr auto" // + operator id for Admin
      : "1fr 1fr 1fr 1fr 0.7fr auto",
  gap: 10,
  margin: "0 0 18px",
  alignItems: "center",
});

const input = {
  padding: "10px 12px",
  border: "1px solid #e9e9ef",
  borderRadius: 10,
  outline: "none",
};

const btnPrimary = {
  padding: "10px 14px",
  borderRadius: 10,
  border: "1px solid #e9e9ef",
  background: "#f7c7e3",
  fontWeight: 700,
  cursor: "pointer",
};
