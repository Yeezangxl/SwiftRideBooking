import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import jsPDF from "jspdf";
import "./BookBusPage.css";
import SeatPicker from "../components/SeatPicker";

export default function BookBusPage() {
  const [locations, setLocations] = useState([]);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedTypes, setSelectedTypes] = useState(["AC", "Non-AC", "Sleeper"]);
  const [sortOrder, setSortOrder] = useState("low-high");
  const [ticket, setTicket] = useState(null);
  const [showSeatModal, setShowSeatModal] = useState(false);
  const [busToBook, setBusToBook] = useState(null);
  const [chosenSeats, setChosenSeats] = useState([]);
  const [boardingPoints, setBoardingPoints] = useState([]);
  const [droppingPoints, setDroppingPoints] = useState([]);
  const [selectedBoarding, setSelectedBoarding] = useState("");
  const [selectedDropping, setSelectedDropping] = useState("");
  const [showToast, setShowToast] = useState(false);

  const navigate = useNavigate();

  // Prevent scroll on modal open
  useEffect(() => {
    if (showSeatModal) {
      document.body.classList.add("modal-open");
    } else {
      document.body.classList.remove("modal-open");
    }
    return () => document.body.classList.remove("modal-open");
  }, [showSeatModal]);

  // Fetch cities for dropdown
  useEffect(() => {
    axios.get("https://localhost:7199/api/Route/locations")
      .then(res => setLocations(res.data))
      .catch(() => setLocations([]));
  }, []);

  // Search buses
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setResults([]);
    try {
      const res = await axios.post("https://localhost:7199/api/Bus/search", {
        from,
        to,
        date
      });
      setResults(res.data);
    } catch (err) {
      setResults([]);
    }
    setLoading(false);
  };

  // Open modal & fetch boarding/dropping points for that bus route
  const handleBook = async (bus) => {
    setBusToBook(bus);
    setShowSeatModal(true);
    setChosenSeats([]);
    setSelectedBoarding("");
    setSelectedDropping("");
    try {
      const [boardingRes, droppingRes] = await Promise.all([
        axios.get(`https://localhost:7199/api/Bus/boardingpoints?routeId=${bus.routeId}`),
        axios.get(`https://localhost:7199/api/Bus/droppingpoints?routeId=${bus.routeId}`)
      ]);
      setBoardingPoints(boardingRes.data);
      setDroppingPoints(droppingRes.data);
    } catch {
      setBoardingPoints([]);
      setDroppingPoints([]);
    }
  };

  // Handle booking with all validations and cute toast!
  const handleConfirmClick = async () => {
    if (!chosenSeats.length || !selectedBoarding || !selectedDropping) {
      setShowToast(true);
      setTimeout(() => setShowToast(false), 2200);
      return;
    }
    await confirmBooking();
  };

  // Book after picking everything
  const confirmBooking = async () => {
    const token = localStorage.getItem("token");
    const user = JSON.parse(localStorage.getItem("user") || "null");
    if (!token || !user) {
      window.alert("Please log in to book a bus!");
      navigate("/login");
      return;
    }
    try {
      const bookingRes = await axios.post(
        "https://localhost:7199/api/Booking",
        {
          busId: busToBook.busId,
          userId: user.userId,
          journeyDate: busToBook.departureTime,
          seatNumbers: chosenSeats.join(","),
          boardingPointId: selectedBoarding,
          droppingPointId: selectedDropping
        },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setShowSeatModal(false);
      setTicket({
        user: user.name || user.email,
        busNo: busToBook.busNumber,
        route: `${busToBook.origin || from} ➔ ${busToBook.destination || to}`,
        departure: busToBook.departureTime ? new Date(busToBook.departureTime).toLocaleString() : "N/A",
        seatNumbers: chosenSeats.join(", "),
        bookingId: bookingRes.data.BookingId || Math.floor(100000 + Math.random() * 900000)
      });
      window.alert("Bus booked successfully! Generating ticket...");
    } catch (err) {
      window.alert("Booking failed: " + (err?.response?.data?.message || "Try again!"));
    }
  };

  // PDF Download
  const handleDownload = () => {
    if (!ticket) return;
    const doc = new jsPDF();
    doc.setFontSize(16);
    doc.text("Swift Ride E-Ticket", 20, 20);
    doc.setFontSize(12);
    doc.text(`Name: ${ticket.user}`, 20, 36);
    doc.text(`Bus No: ${ticket.busNo}`, 20, 48);
    doc.text(`Route: ${ticket.route}`, 20, 60);
    doc.text(`Departure: ${ticket.departure}`, 20, 72);
    doc.text(`Seat: ${ticket.seatNumbers || "N/A"}`, 20, 84);
    doc.text(`Booking ID: ${ticket.bookingId}`, 20, 96);
    doc.save(`SwiftRide_Ticket_${ticket.bookingId}.pdf`);
  };

  // Bus type filter checkbox
  const toggleType = (type) => {
    setSelectedTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  // Filter + sort
  let filteredResults = results.filter(bus =>
    selectedTypes.includes(bus.busType)
  );
  filteredResults = [...filteredResults].sort((a, b) => {
    if (!a.price || !b.price) return 0;
    return sortOrder === "low-high"
      ? a.price - b.price
      : b.price - a.price;
  });

  return (
    <div className="bookbus-container">
      {/* FILTER SIDEBAR */}
      <div className="filter-sidebar">
        <div className="filter-title">Filter By Bus Type</div>
        {["AC", "Non-AC", "Sleeper"].map(type => (
          <label key={type} className="filter-label">
            <input
              type="checkbox"
              checked={selectedTypes.includes(type)}
              onChange={() => toggleType(type)}
            /> {type}
          </label>
        ))}
      </div>
      {/* MAIN SEARCH & RESULTS */}
      <div className="main-content">
        <h2 className="main-title">Find Your Swift Ride</h2>
        <form onSubmit={handleSubmit} className="search-form">
          <select value={from} onChange={e => setFrom(e.target.value)} required>
            <option value="">From (select city)</option>
            {locations.map(city =>
              <option key={city} value={city}>{city}</option>
            )}
          </select>
          <select value={to} onChange={e => setTo(e.target.value)} required>
            <option value="">To (select city)</option>
            {locations.map(city =>
              <option key={city} value={city}>{city}</option>
            )}
          </select>
          <input
            type="date"
            value={date}
            onChange={e => setDate(e.target.value)}
            required
          />
          <button type="submit" disabled={loading}>
            {loading ? "Searching..." : "Search"}
          </button>
        </form>
        {/* SORT BY PRICE */}
        {filteredResults.length > 0 && (
          <div className="sort-row">
            <span>Sort by Price:</span>
            <select value={sortOrder} onChange={e => setSortOrder(e.target.value)}>
              <option value="low-high">Low to High</option>
              <option value="high-low">High to Low</option>
            </select>
          </div>
        )}
        <div className="bus-results">
          {filteredResults.length === 0 && !loading ? (
            <div className="no-bus-text">
              No buses yet. Try searching!
            </div>
          ) : (
            filteredResults.map((bus, idx) => (
              <div key={bus.busId || idx} className="bus-card">
                <div><b>Bus No:</b> {bus.busNumber}</div>
                <div><b>Type:</b> {bus.busType}</div>
                <div><b>Seats:</b> {bus.totalSeats}</div>
                <div><b>Price:</b> ₹{bus.price ? bus.price : "N/A"}</div>
                <div><b>Departure:</b> {bus.departureTime ? new Date(bus.departureTime).toLocaleString() : "N/A"}</div>
                <button onClick={() => handleBook(bus)}>
                  Book
                </button>
              </div>
            ))
          )}
        </div>

        {/* SEAT PICKER MODAL */}
        {showSeatModal && busToBook && (
          <div className="modal-bg" onClick={() => setShowSeatModal(false)}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
              <button className="modal-close-btn" onClick={() => setShowSeatModal(false)}>×</button>
              <h3>Select Boarding & Dropping Points for {busToBook.busNumber}</h3>
              <select
                value={selectedBoarding}
                onChange={e => setSelectedBoarding(e.target.value)}
                required
                style={{ marginBottom: 12, width: "100%" }}
              >
                <option value="">Choose Boarding Point</option>
                {boardingPoints.map(pt => (
                  <option key={pt.boardingPointId} value={pt.boardingPointId}>{pt.point}</option>
                ))}
              </select>
              <select
                value={selectedDropping}
                onChange={e => setSelectedDropping(e.target.value)}
                required
                style={{ marginBottom: 18, width: "100%" }}
              >
                <option value="">Choose Dropping Point</option>
                {droppingPoints.map(pt => (
                  <option key={pt.droppingPointId} value={pt.droppingPointId}>{pt.point}</option>
                ))}
              </select>
              <SeatPicker
                busId={busToBook.busId}
                date={busToBook.departureTime}
                onChange={setChosenSeats}
              />
              <button
                className="auth-btn"
                style={{ marginTop: 18, width: "100%" }}
                onClick={handleConfirmClick}
                disabled={!selectedBoarding || !selectedDropping || chosenSeats.length === 0}
              >
                Confirm Booking
              </button>
              {showToast && (
                <div className="toast">
                  🚫 Please select seat, boarding and dropping point!
                </div>
              )}
            </div>
          </div>
        )}

        {/* E-Ticket Modal */}
        {ticket && (
          <div className="ticket-modal">
            <div className="ticket-content">
              <h3>🎫 Swift Ride E-Ticket</h3>
              <div><b>Name:</b> {ticket.user}</div>
              <div><b>Bus No:</b> {ticket.busNo}</div>
              <div><b>Route:</b> {ticket.route}</div>
              <div><b>Departure:</b> {ticket.departure}</div>
              <div><b>Seat:</b> {ticket.seatNumbers}</div>
              <div><b>Booking ID:</b> {ticket.bookingId}</div>
              <button className="download-btn" onClick={handleDownload}>
                Download as PDF
              </button>
              <button className="close-btn" onClick={() => setTicket(null)}>
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
