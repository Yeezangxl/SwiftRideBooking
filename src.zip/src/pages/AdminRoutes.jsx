import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "https://localhost:7199";

export default function AdminRoutes() {
  const [routes, setRoutes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");

  const [origin, setOrigin] = useState("");
  const [destination, setDestination] = useState("");
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState(null);

  async function fetchRoutes() {
    try {
      setLoading(true);
      const res = await axios.get(`${API}/api/Route`);
      setRoutes(res.data || []);
    } catch (e) {
      setErr(e?.response?.data || e.message);
    } finally {
      setLoading(false);
    }
  }

  async function addRoute(e) {
    e.preventDefault();
    try {
      setSaving(true);
      await axios.post(`${API}/api/Route`, { origin, destination });
      setOrigin(""); setDestination("");
      fetchRoutes();
    } catch (e) {
      alert(e?.response?.data || e.message);
    } finally {
      setSaving(false);
    }
  }

  async function deleteRoute(id) {
    if (!window.confirm("Delete route?")) return;
    try {
      setDeletingId(id);
      await axios.delete(`${API}/api/Route/${id}`);
      setRoutes(prev => prev.filter(r => r.routeId !== id));
    } catch (e) {
      alert(e?.response?.data || e.message);
    } finally {
      setDeletingId(null);
    }
  }

  useEffect(() => { fetchRoutes(); }, []);

  return (
    <div style={{ padding: 40 }}>
      <h2 style={{ color: "#8e24aa", textAlign: "center" }}>Manage Routes</h2>

      <form onSubmit={addRoute} style={{ margin: "16px 0", display:"flex", gap:12 }}>
        <input placeholder="Origin" value={origin} onChange={e=>setOrigin(e.target.value)} required />
        <input placeholder="Destination" value={destination} onChange={e=>setDestination(e.target.value)} required />
        <button type="submit" disabled={saving}>{saving? "Saving..." : "Add Route"}</button>
      </form>

      {loading ? <p>Loading...</p> : err ? <p style={{color:'crimson'}}>{String(err)}</p> : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={th}>RouteId</th>
              <th style={th}>Origin</th>
              <th style={th}>Destination</th>
              <th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {routes.map(r => (
              <tr key={r.routeId}>
                <td style={td}>{r.routeId}</td>
                <td style={td}>{r.origin}</td>
                <td style={td}>{r.destination}</td>
                <td style={{...td, textAlign:"right"}}>
                  <button onClick={() => deleteRoute(r.routeId)} disabled={deletingId===r.routeId}>
                    {deletingId===r.routeId ? "Deleting..." : "Delete"}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

const th = { borderBottom: "1px solid #eee", padding: 12, textAlign: "left" };
const td = { borderBottom: "1px solid #f4f4f4", padding: 12 };
