import React, { useState } from "react";
import logo from "../assets/logo.png";
import "./Register.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const RegisterPage = () => {
  const [name, setName] = useState(""); // Optional: backend ignores, but nice UX
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);
    try {
      await axios.post("https://localhost:7199/api/Users/register", {
        email,
        password,
      });
      setSuccess("Registration successful! You can now log in.");
      setTimeout(() => {
        navigate("/login");
      }, 1200);
    } catch (err) {
      setError(
        err.response?.data || "Registration failed! Email might already be in use."
      );
    }
    setLoading(false);
  };

  return (
    <div className="auth-bg d-flex align-items-center justify-content-center min-vh-100">
      <div className="auth-card">
        <img src={logo} alt="Swift Ride Logo" className="auth-logo" />
        <h2 className="auth-title">Register</h2>
        <p className="auth-subtitle">Sign up to ride Swift!</p>
        <form onSubmit={handleSubmit}>
          <input
            className="auth-input"
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Enter name"
            disabled={loading}
          />
          <input
            className="auth-input"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="Enter email"
            required
            disabled={loading}
          />
          <input
            className="auth-input"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Password"
            required
            disabled={loading}
          />
          <button className="auth-btn" type="submit" disabled={loading}>
            {loading ? "Registering..." : "Register"}
          </button>
        </form>
        {error && (
          <div style={{ color: "#d42a2a", marginTop: 10, fontWeight: 500 }}>
            {typeof error === "string" ? error : JSON.stringify(error)}
          </div>
        )}
        {success && (
          <div style={{ color: "#239c4d", marginTop: 10, fontWeight: 500 }}>
            {success}
          </div>
        )}
      </div>
    </div>
  );
};

export default RegisterPage;
