// src/pages/RegisterPage.jsx
import React, { useMemo, useState } from "react";
import logo from "../assets/logo.png";
import "./Register.css";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const API_BASE = "https://localhost:7199";

// Strong password rules:
//  • ≥12 chars, includes upper, lower, digit, special, and no spaces
function evaluatePassword(pw) {
  const checks = {
    upper: /[A-Z]/.test(pw),
    lower: /[a-z]/.test(pw),
    digit: /\d/.test(pw),
    special: /[^A-Za-z0-9]/.test(pw),
    length12: pw.length >= 12,
    noSpaces: !/\s/.test(pw),
  };
  const validStrong =
    checks.length12 &&
    checks.noSpaces &&
    checks.upper &&
    checks.lower &&
    checks.digit &&
    checks.special;
  return { checks, validStrong };
}

const RegisterPage = () => {
  const navigate = useNavigate();

  const [name, setName] = useState(""); // optional
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [touchedPw, setTouchedPw] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const pwEval = useMemo(() => evaluatePassword(password), [password]);
  const emailLooksOk = useMemo(
    () => !!email && email.includes("@") && email.includes("."),
    [email]
  );

  const mismatch = confirm.length > 0 && confirm !== password;
  const showPwRules = (touchedPw || password.length > 0) && !pwEval.validStrong;

  const canSubmit =
    emailLooksOk &&
    pwEval.validStrong &&
    !mismatch &&
    confirm.length > 0 &&
    !loading;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setSuccess("");

    if (!canSubmit) {
      if (!emailLooksOk) return setError("Please enter a valid email.");
      if (!pwEval.validStrong)
        return setError(
          "Password must be STRONG: 12+ chars with upper, lower, digit, special, and no spaces."
        );
      if (mismatch) return setError("Passwords do not match.");
      return;
    }

    try {
      setLoading(true);
      await axios.post(`${API_BASE}/api/Users/register`, {
        email: email.trim(),
        password,
      });
      setSuccess("Registration successful! Redirecting to login…");
      setTimeout(() => navigate("/login"), 900);
    } catch (err) {
      const msg =
        err?.response?.data ||
        err?.message ||
        "Registration failed! Email might already be in use.";
      setError(typeof msg === "string" ? msg : "Registration failed.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-bg d-flex align-items-center justify-content-center min-vh-100">
      <div className="auth-card">
        <img src={logo} alt="Swift Ride Logo" className="auth-logo" />
        <h2 className="auth-title">Register</h2>
        <p className="auth-subtitle">Sign up to ride Swift!</p>

        <form onSubmit={handleSubmit} noValidate>
          <input
            className="auth-input"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter name (optional)"
            disabled={loading}
            autoComplete="name"
          />

          <input
            className="auth-input"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter email"
            required
            disabled={loading}
            autoComplete="email"
          />

          <input
            className="auth-input"
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (!touchedPw) setTouchedPw(true);
            }}
            placeholder="Password"
            required
            disabled={loading}
            autoComplete="new-password"
          />

          {/* RULES: only while invalid */}
          {showPwRules && (
            <ul className="pw-hints">
              <li className={pwEval.checks.length12 ? "ok" : ""}>
                At least 12 characters
              </li>
              <li className={pwEval.checks.upper ? "ok" : ""}>
                One uppercase letter
              </li>
              <li className={pwEval.checks.lower ? "ok" : ""}>
                One lowercase letter
              </li>
              <li className={pwEval.checks.digit ? "ok" : ""}>One digit</li>
              <li className={pwEval.checks.special ? "ok" : ""}>
                One special character
              </li>
              <li className={pwEval.checks.noSpaces ? "ok" : ""}>No spaces</li>
            </ul>
          )}

          <input
            className={`auth-input ${mismatch ? "invalid" : ""}`}
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            placeholder="Confirm password"
            required
            disabled={loading}
            autoComplete="new-password"
            aria-invalid={mismatch ? "true" : "false"}
            aria-describedby={mismatch ? "confirm-help" : undefined}
          />
          {mismatch && (
            <div
              id="confirm-help"
              className="field-hint error"
              aria-live="polite"
            >
              Passwords don’t match
            </div>
          )}

          <button className="auth-btn" type="submit" disabled={!canSubmit}>
            {loading ? "Registering..." : "Register"}
          </button>
        </form>

        {error && (
          <div style={{ color: "#d42a2a", marginTop: 10, fontWeight: 500 }}>
            {typeof error === "string" ? error : JSON.stringify(error)}
          </div>
        )}
        {success && (
          <div style={{ color: "#239c4d", marginTop: 10, fontWeight: 500 }}>
            {success}
          </div>
        )}
      </div>

      {/* small styles for hints + invalid state if your CSS doesn't have them */}
      <style>{`
        .pw-hints {
          margin: 8px 0 10px;
          padding-left: 18px;
          font-size: 13px;
          line-height: 1.4;
          color: #555;
        }
        .pw-hints li.ok { color: #239c4d; font-weight: 600; }
        .field-hint.error { margin-top: 6px; font-size: 12px; color: #d42a2a; }
        .auth-input.invalid { border-color: #d42a2a !important; box-shadow: 0 0 0 2px rgba(212,42,42,.08); }
      `}</style>
    </div>
  );
};

export default RegisterPage;
