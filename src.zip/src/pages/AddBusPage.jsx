import React, { useState, useEffect } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./AddBusPage.css";

const AddBusPage = () => {
  const [routes, setRoutes] = useState([]);
  const [routeId, setRouteId] = useState("");
  const [busNumber, setBusNumber] = useState("");
  const [busType, setBusType] = useState("AC");
  const [totalSeats, setTotalSeats] = useState(40);
  const [departureTime, setDepartureTime] = useState("");
  const [boardingPoints, setBoardingPoints] = useState([]);
  const [droppingPoints, setDroppingPoints] = useState([]);
  const [boardingPointId, setBoardingPointId] = useState("");
  const [droppingPointId, setDroppingPointId] = useState("");
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState(""); // "boarding" or "dropping"
  const [newPoint, setNewPoint] = useState("");
  const [addingPoint, setAddingPoint] = useState(false);
  const navigate = useNavigate();

  // Fetch all routes for dropdown
  useEffect(() => {
    axios.get("https://localhost:7199/api/Route")
      .then(res => setRoutes(res.data))
      .catch(() => setRoutes([]));
  }, []);

  // Fetch boarding & dropping points for selected route
  const fetchPoints = () => {
    if (!routeId) {
      setBoardingPoints([]);
      setDroppingPoints([]);
      setBoardingPointId("");
      setDroppingPointId("");
      return;
    }
    axios.get(`https://localhost:7199/api/Bus/boardingpoints?routeId=${routeId}`)
      .then(res => setBoardingPoints(res.data))
      .catch(() => setBoardingPoints([]));
    axios.get(`https://localhost:7199/api/Bus/droppingpoints?routeId=${routeId}`)
      .then(res => setDroppingPoints(res.data))
      .catch(() => setDroppingPoints([]));
  };

  useEffect(() => {
    fetchPoints();
    // eslint-disable-next-line
  }, [routeId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    try {
      const token = localStorage.getItem("token");
      const user = JSON.parse(localStorage.getItem("user") || "{}");
      // Try both variants for BusOperatorId (sometimes camelCase, sometimes PascalCase)
      const busOperatorId = user.busOperatorId || user.BusOperatorId || null;
      // If role is operator, include operator ID
      let body = {
        routeId,
        busNumber,
        busType,
        totalSeats,
        departureTime,
        boardingPointId,
        droppingPointId
      };
      if ((user.role || user.Role || "").toLowerCase().includes("operator")) {
        body.busOperatorId = busOperatorId;
      }
      await axios.post("https://localhost:7199/api/Bus", body, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMessage("Bus added successfully!");
      // Redirect by role!
      if ((user.role || user.Role || "").toLowerCase().includes("operator"))
        setTimeout(() => navigate("/operator/dashboard"), 1200);
      else
        setTimeout(() => navigate("/admin/dashboard"), 1200);
    } catch (err) {
      setMessage("Failed to add bus! Are you logged in as Admin or Operator?");
    }
    setLoading(false);
  };

  // Open modal for adding point
  const openModal = (type) => {
    setModalType(type); // "boarding" or "dropping"
    setShowModal(true);
    setNewPoint("");
  };

  // Add new boarding/dropping point
  const handleAddPoint = async () => {
    if (!routeId || !newPoint.trim()) return;
    setAddingPoint(true);
    try {
      const token = localStorage.getItem("token");
      // Decide endpoint & body
      const endpoint =
        modalType === "boarding"
          ? "https://localhost:7199/api/Bus/boardingpoints"
          : "https://localhost:7199/api/Bus/droppingpoints";
      const res = await axios.post(
        endpoint,
        { routeId, point: newPoint.trim() },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setShowModal(false);
      setNewPoint("");
      // Refresh & auto-select the new point
      fetchPoints();
      setTimeout(() => {
        if (modalType === "boarding") {
          setBoardingPointId(res.data.boardingPointId || res.data.id || "");
        } else {
          setDroppingPointId(res.data.droppingPointId || res.data.id || "");
        }
      }, 400);
    } catch (err) {
      alert("Failed to add point! Try again.");
    }
    setAddingPoint(false);
  };

  return (
    <div className="addbus-bg">
      <div className="addbus-container">
        <h2 className="addbus-title">Add New Bus</h2>
        <form className="addbus-form" onSubmit={handleSubmit}>
          <select
            className="addbus-input"
            value={routeId}
            onChange={e => setRouteId(e.target.value)}
            required
          >
            <option value="">Select Route</option>
            {routes.map(r => (
              <option key={r.routeId} value={r.routeId}>
                {r.origin} ➔ {r.destination}
              </option>
            ))}
          </select>
          <input
            className="addbus-input"
            type="text"
            value={busNumber}
            onChange={e => setBusNumber(e.target.value)}
            placeholder="Bus Number"
            required
          />
          <select
            className="addbus-input"
            value={busType}
            onChange={e => setBusType(e.target.value)}
            required
          >
            <option value="AC">AC</option>
            <option value="Non-AC">Non-AC</option>
            <option value="Sleeper">Sleeper</option>
          </select>
          <input
            className="addbus-input"
            type="number"
            value={totalSeats}
            onChange={e => setTotalSeats(e.target.value)}
            min={10}
            max={100}
            placeholder="Total Seats"
            required
          />
          <input
            className="addbus-input"
            type="datetime-local"
            value={departureTime}
            onChange={e => setDepartureTime(e.target.value)}
            required
          />

          <div style={{ display: "flex", gap: 8 }}>
            <select
              className="addbus-input"
              style={{ flex: 1 }}
              value={boardingPointId}
              onChange={e => setBoardingPointId(e.target.value)}
              required
              disabled={!boardingPoints.length}
            >
              <option value="">Select Boarding Point</option>
              {boardingPoints.map(bp => (
                <option key={bp.boardingPointId} value={bp.boardingPointId}>
                  {bp.point}
                </option>
              ))}
            </select>
            {/* Add Boarding Point button */}
            <button
              type="button"
              className="addbus-btn"
              style={{
                padding: "0 16px",
                fontSize: 24,
                minWidth: 0,
                borderRadius: 10,
                background: "#e1bee7",
                color: "#8e24aa",
                fontWeight: 900,
                marginTop: 0,
                height: 48,
                alignSelf: "center",
              }}
              onClick={() => openModal("boarding")}
              disabled={!routeId}
              title="Add Boarding Point"
            >
              +
            </button>
          </div>

          <div style={{ display: "flex", gap: 8 }}>
            <select
              className="addbus-input"
              style={{ flex: 1 }}
              value={droppingPointId}
              onChange={e => setDroppingPointId(e.target.value)}
              required
              disabled={!droppingPoints.length}
            >
              <option value="">Select Dropping Point</option>
              {droppingPoints.map(dp => (
                <option key={dp.droppingPointId} value={dp.droppingPointId}>
                  {dp.point}
                </option>
              ))}
            </select>
            {/* Add Dropping Point button */}
            <button
              type="button"
              className="addbus-btn"
              style={{
                padding: "0 16px",
                fontSize: 24,
                minWidth: 0,
                borderRadius: 10,
                background: "#e1bee7",
                color: "#8e24aa",
                fontWeight: 900,
                marginTop: 0,
                height: 48,
                alignSelf: "center",
              }}
              onClick={() => openModal("dropping")}
              disabled={!routeId}
              title="Add Dropping Point"
            >
              +
            </button>
          </div>

          <button className="addbus-btn" type="submit" disabled={loading}>
            {loading ? "Adding..." : "Add Bus"}
          </button>
        </form>
        {message && (
          <div className={`addbus-msg ${message.includes("success") ? "success" : "error"}`}>
            {message}
          </div>
        )}
      </div>

      {/* Modal for adding point */}
      {showModal && (
        <div className="modal-bg" style={{
          position: "fixed", left: 0, top: 0, width: "100vw", height: "100vh",
          background: "rgba(100,40,160,0.18)", zIndex: 9999, display: "flex", alignItems: "center", justifyContent: "center"
        }}>
          <div className="modal-content" style={{
            background: "#fff",
            padding: 28,
            borderRadius: 18,
            boxShadow: "0 2px 20px #b478d980",
            minWidth: 320,
            maxWidth: "90vw",
            textAlign: "center"  
          }}>
            <h3 style={{ color: "#8e24aa", marginBottom: 14 }}>
              Add New {modalType === "boarding" ? "Boarding" : "Dropping"} Point
            </h3>
            <input
              className="addbus-input"
              style={{ width: "90%", margin: "0 auto" }}
              value={newPoint}
              onChange={e => setNewPoint(e.target.value)}
              placeholder="Enter Point Name"
              autoFocus
            />
            <div style={{ marginTop: 16, display: "flex", gap: 12, justifyContent: "center" }}>
              <button
                className="addbus-btn"
                onClick={handleAddPoint}
                disabled={addingPoint || !newPoint.trim()}
                style={{ minWidth: 100 }}
              >
                {addingPoint ? "Adding..." : "Add"}
              </button>
              <button
                className="addbus-btn"
                style={{
                  background: "#faf7ff",
                  color: "#8e24aa",
                  boxShadow: "none",
                  border: "1.5px solid #e1bee7"
                }}
                onClick={() => setShowModal(false)}
                disabled={addingPoint}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default AddBusPage;
