import React, { useState } from "react";
import logo from "../assets/logo.png";
import "./Register.css"; // Uses your existing styles!
import { useNavigate } from "react-router-dom";
import axios from "axios";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await axios.post("https://localhost:7199/api/Users/login", {
        email,
        password
      });
      // Save token and user info
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("user", JSON.stringify(res.data.user));
      // Redirect by role
      const role = res.data.user.role?.toLowerCase();
      if (role === "admin") {
        navigate("/admin/dashboard");
      } else if (role === "busoperator" || role === "bus operator") {
        navigate("/operator/dashboard");
      } else {
        navigate("/"); // <<--- USER lands on Home/Search page!
      }
    } catch (err) {
      setError(
        err.response?.data || "Login failed! Please check your credentials."
      );
    }
    setLoading(false);
  };

  return (
    <div className="auth-bg d-flex align-items-center justify-content-center min-vh-100">
      <div className="auth-card">
        <img src={logo} alt="Swift Ride Logo" className="auth-logo" />
        <h2 className="auth-title">Swift Ride Login</h2>
        <form onSubmit={handleSubmit}>
          <input
            className="auth-input"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="Enter your email"
            required
            disabled={loading}
          />
          <input
            className="auth-input"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
            disabled={loading}
          />
          <button className="auth-btn" type="submit" disabled={loading}>
            {loading ? "Logging in..." : "Login"}
          </button>
        </form>
        {error && (
          <div style={{ color: "#d42a2a", marginTop: 10, fontWeight: 500 }}>
            {typeof error === "string" ? error : JSON.stringify(error)}
          </div>
        )}
        <div className="text-center mt-3">
          <span>Don't have an account? </span>
          <a href="/register" className="auth-link">Register</a>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
