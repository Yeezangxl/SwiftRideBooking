// src/App.js
import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import HomePage from "./pages/HomePage";
import BookBusPage from "./pages/BookBusPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import AdminDashboard from "./pages/AdminDashboard";
import OperatorDashboard from "./pages/OperatorDashboard";
import UserDashboard from "./pages/UserDashboard";
import ProtectedRoute from "./components/ProtectedRoute";
import AddBusPage from "./pages/AddBusPage";
import ManageBusesPage from "./pages/ManageBusesPage";
import OperatorBuses from "./pages/OperatorBuses";

// NEW: Admin management pages
import AdminUsers from "./pages/AdminUsers";
import AdminOperators from "./pages/AdminOperators";
import AdminRoutes from "./pages/AdminRoutes";
import AdminBookings from "./pages/AdminBookings";

// NEW: User Profile
import UserProfile from "./pages/UserProfile";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/book" element={<BookBusPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Admin */}
        <Route path="/admin/dashboard" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
        <Route path="/admin/users" element={<ProtectedRoute><AdminUsers /></ProtectedRoute>} />
        <Route path="/admin/operators" element={<ProtectedRoute><AdminOperators /></ProtectedRoute>} />
        <Route path="/admin/routes" element={<ProtectedRoute><AdminRoutes /></ProtectedRoute>} />
        <Route path="/admin/buses" element={<ProtectedRoute><ManageBusesPage /></ProtectedRoute>} />
        <Route path="/admin/bookings" element={<ProtectedRoute><AdminBookings /></ProtectedRoute>} />

        {/* Operator */}
        <Route path="/operator/dashboard" element={<ProtectedRoute><OperatorDashboard /></ProtectedRoute>} />
        <Route path="/operator/buses" element={<ProtectedRoute><ManageBusesPage /></ProtectedRoute>} />
        <Route path="/operator/buses-old" element={<OperatorBuses />} />

        {/* Add bus */}
        <Route path="/add-bus" element={<ProtectedRoute><AddBusPage /></ProtectedRoute>} />

        {/* User */}
        <Route path="/user/dashboard" element={<ProtectedRoute><UserDashboard /></ProtectedRoute>} />
        <Route path="/user/profile" element={<ProtectedRoute><UserProfile /></ProtectedRoute>} />

        {/* 404 */}
        <Route path="*" element={
          <div style={{ padding: 40, textAlign: "center", color: "#b478d9", fontWeight: 700, fontSize: "2rem" }}>
            404 | Page Not Found
          </div>
        }/>
      </Routes>
    </BrowserRouter>
  );
}
export default App;
