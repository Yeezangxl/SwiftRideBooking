// src/components/Navbar.js
import React from "react";
import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";

export default function Navbar() {
  const navigate = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "null");
  const role = user?.role?.toLowerCase();

  function handleLogout(e) {
    e.preventDefault();
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    navigate("/login");
  }

  return (
    <nav
      style={{
        height: 72,
        background: "#fff",
        boxShadow: "0 1px 6px rgba(166,120,221,0.18)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 38px",
      }}
    >
      <div style={{ display: "flex", alignItems: "center" }}>
        <img
          src={logo}
          alt="Swift Ride Logo"
          style={{
            height: 52,
            marginRight: 14,
            background: "#fff",
            borderRadius: 10,
            boxShadow: "0 1px 6px rgba(166,120,221,0.18)",
          }}
        />
        <span
          style={{
            fontWeight: "bold",
            color: "#a678dd",
            fontSize: "1.7rem",
          }}
        >
          Swift Ride
        </span>
      </div>
      <div>
        {/* Admin */}
        {role === "admin" && (
          <>
            <Link to="/admin/dashboard" style={{ marginRight: 24 }}>
              Admin Dashboard
            </Link>
            <Link to="/add-bus" style={{ marginRight: 24, color: "#23a463" }}>
              + Add Bus
            </Link>
          </>
        )}
        {/* Bus Operator */}
        {role === "busoperator" || role === "bus operator" ? (
          <>
            <Link to="/operator/dashboard" style={{ marginRight: 24 }}>
              Operator Dashboard
            </Link>
            <Link to="/add-bus" style={{ marginRight: 24, color: "#23a463" }}>
              + Add Bus
            </Link>
          </>
        ) : null}
        {/* User */}
        {role === "user" && (
          <Link to="/user/dashboard" style={{ marginRight: 24 }}>
            My Bookings
          </Link>
        )}
        {/* Not logged in */}
        {!role && (
          <>
            <Link to="/login" style={{ marginRight: 24 }}>
              Login
            </Link>
            <Link to="/register" style={{ marginRight: 24 }}>
              Register
            </Link>
          </>
        )}
        {/* Logout if logged in */}
        {role && (
          <a href="/logout" style={{ color: "#8e24aa" }} onClick={handleLogout}>
            Logout
          </a>
        )}
      </div>
    </nav>
  );
}
