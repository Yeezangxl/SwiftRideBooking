import React, { useEffect, useState } from "react";
import axios from "axios";
import "./SeatPicker.css"; // If you want custom seat grid styles!

const rows = ["A", "B", "C", "D"];
const cols = [1,2,3,4,5,6,7,8,9,10];

export default function SeatPicker({ busId, date, onChange }) {
  const [booked, setBooked] = useState([]);
  const [selected, setSelected] = useState([]);

  useEffect(() => {
    if (!busId || !date) return;
    axios.get(`https://localhost:7199/api/Booking/bookedseats`, {
      params: { busId, date }
    })
      .then(res => setBooked(res.data))
      .catch(() => setBooked([]));
    setSelected([]);
  }, [busId, date]);

  const toggleSeat = (seat) => {
    if (booked.includes(seat)) return;
    setSelected(sel =>
      sel.includes(seat) ? sel.filter(s => s !== seat) : [...sel, seat]
    );
  };

  useEffect(() => {
    onChange && onChange(selected);
  }, [selected, onChange]);

  return (
    <div className="seat-grid">
      {rows.map(row =>
        cols.map(col => {
          const seat = `${row}${col}`;
          const isBooked = booked.includes(seat);
          const isSelected = selected.includes(seat);
          return (
            <button
              key={seat}
              className={`seat-btn ${isBooked ? "booked" : isSelected ? "selected" : ""}`}
              onClick={() => toggleSeat(seat)}
              disabled={isBooked}
              type="button"
            >
              {seat}
            </button>
          );
        })
      )}
    </div>
  );
}
